<?php
include('data_config.php');
$conn = new connection;

    $query_del = "update masters_city set is_delete = 1 where city_id = ".$_GET['city_delete_id'];
    $result = $conn->conn->query($query_del);
    if($result)
    {
    	header('Location:city.php');
    }
?>