<!DOCTYPE html>
<html lang="en">

<?php
   include('data_config.php');
   include('route.class.php');
   $conn = new connection;
   $rout = new route();

   //var_dump($conn);die;


    $query_bus_list = "select bus_id,bus_name from master_bus where is_delete = 0 and status = 1 ";
    $bus_list = $conn->conn->query($query_bus_list);
    //var_dump($bus_list);die;
    $i = 0;
    while($row_auto  = mysqli_fetch_assoc($bus_list))
    {
       $bus_autocomplete[$i]['label'] = $row_auto['bus_name'];
       $bus_autocomplete[$i]['value'] = $row_auto['bus_id'];
       $i++;
    }
    $result_data_bus = json_encode($bus_autocomplete);

    $j = 0;
    $query_stop_list = "select stop_id,stop_name from master_stop where is_delete = 0 and status = 1";
    $stop_list = $conn->conn->query($query_stop_list);
    while($row_stop_auto  = mysqli_fetch_assoc($stop_list))
    {
       $stop_autocomplete[$j]['label'] = $row_stop_auto['stop_name'];
       $stop_autocomplete[$j]['value'] = $row_stop_auto['stop_id'];
       $j++;
    }
    $stop_result_data = json_encode($stop_autocomplete);

    $k = 0;
    $query_city_list = "select city_id,city_name from masters_city where is_delete = 0 AND status = 1 ";
    $city_list = $conn->conn->query($query_city_list);
    while($row_city_auto  = mysqli_fetch_assoc($city_list))
    {
       $city_autocomplete[$k]['label'] = $row_city_auto['city_name'];
       $city_autocomplete[$k]['value'] = $row_city_auto['city_id'];
       $k++;
    }
    $city_result_data = json_encode($city_autocomplete);
    //echo "<pre>";print_r($city_result_data );die;

    if(!empty($_GET['rout_id']))
    {
        $qry_fetch = "select * from bus_route_master where is_delete = 0  AND route_id = ".$_GET['rout_id'];
         $fetch_route_list = $conn->conn->query($qry_fetch);
        while($row_route  = mysqli_fetch_assoc($fetch_route_list))
        {
           $routes_flow = $row_route;
        }


        $qry_fetch_stop = "select * from route_bus_stop_master where is_delete = 0 AND route_id = ".$_GET['rout_id']." order by stop_order asc" ;
         $fetch_stop_list = $conn->conn->query($qry_fetch_stop);
        while($stop_route  = mysqli_fetch_assoc($fetch_stop_list))
        {
           $stop_flow[] = $stop_route;
        }
        //echo "<pre>";print_r($stop_flow);die;
    }



    if(isset($_POST['submit']))
    {
        //   echo "<pre>";print_r($_POST);


        $bus_id = $_POST['bus_list'];
        $bus_source_id = $_POST['b_source_val'];
        $bus_destination_id = $_POST['b_Destination_val']; 
        $bus_fair = $_POST['b_fair'];
        $bus_seat = $_POST['b_seat']; 
        $b_desc = $_POST['b_desc'];
        $status = $_POST['status']; 
        $bus_type = $_POST['bus_type'];
        $contact_no = $_POST['contact_no']; 
       // $arrival_date = date('Y-m-d H:i:s', strtotime(str_replace('-', '/', $arrival_date)));
        $today = date("Y-m-d h:i:sa");


        if(!empty($_POST['route_id']))
        {
            $update_qry = "update bus_route_master set source = '".$bus_source_id."',destination = '".$bus_destination_id."',bus_id = '".$bus_id."',bus_fair = '".$bus_fair."',bus_total_seat = '".$bus_seat."',bus_description = '".$b_desc."',contact_no = '".$contact_no."',updated_date = '".$today."',status = '".$status."',bus_type = '".$bus_type."' where route_id = '".$_POST['route_id']."'";
            $update_route = $conn->conn->query($update_qry);

        }else{
         $insert_qry = "insert into bus_route_master values('','".$bus_source_id."','".$bus_destination_id."','".$bus_id."','".$bus_fair."','".$bus_seat."','','','".$b_desc."','".$bus_type."','".$status."','".$contact_no."','".$today."','',0)";
         $result_insert = $conn->conn->query($insert_qry);
         $last_insert_id = $conn->conn->insert_id;
        }

        if(!empty($_POST['route_id']))
        {   
            //echo 123;die;
            $stp_ids = array();
            $route_stp_stop_list = "select stop_route_id from route_bus_stop_master where is_delete = 0 AND route_id = ".$_POST['route_id'];
            $list_route_stop_id = $conn->conn->query($route_stp_stop_list);
            while($route_id_stop_auto  = mysqli_fetch_assoc($list_route_stop_id))
            {
               $stp_ids[] = $route_id_stop_auto['stop_route_id'];
            }
            
            $del_ids = array_diff($stp_ids, $_POST['stop_route_id']);
            //echo "<pre>";print_r($stp_ids); echo "<br />";echo "<pre>";print_r( $_POST['stop_route_id']);echo "<br />";var_dump($del_ids);die;

            if(!empty($del_ids))
            {
                //echo 123;die;
                $ids = implode(",", $del_ids);
                $del_qry = "update route_bus_stop_master set is_delete = 1 where stop_route_id IN (".$ids.")";
                $conn->conn->query($del_qry);
            }
            //echo "<pre>";print_r($del_ids);die;
        }


        
        $stop = array();
        $stop = $_POST['stopname'];
        //$contactno = $_POST['contactno'];
        $time1 = $_POST['time1'];
        if(!empty($stop))
        {

        if(!empty($_POST['route_id']))
        {
            $stop_route_id = $_POST['stop_route_id'];
            foreach($stop as $key=>$val)
          {
            if(!empty($stop_route_id[$key])){
              $stop_update_query = "update route_bus_stop_master set route_id = '".$_POST['route_id']."', stop_id = '".$stop[$key]."', stop_time = '".$time1[$key]."', updated_date = '".$today."',stop_order = '".$key."' where stop_route_id = '".$stop_route_id[$key]."'";
            }else
            {
                //echo 123;die;
             $stop_update_query = "insert into route_bus_stop_master values('','".$_POST['route_id']."','".$stop[$key]."','".$time1[$key]."','".$key."','".$today."','',0)";
            }
            $stop_update_insert = $conn->conn->query($stop_update_query);

          }
         // die;
         // die;
          if($stop_update_insert)
            {
               $msg = "<div class='alert alert-success display_msg'>Route updated Successfully</div>";
               header("Refresh:0");
            }else{
               $msg = "<div class='alert alert-danger display_msg'>Error occuerd</div>";
            }
        }else
        {
          foreach($stop as $key=>$val)
          {
            $stop_query = "insert into route_bus_stop_master values('','".$last_insert_id."','".$stop[$key]."','".$time1[$key]."','".$key."','".$today."','',0)";
            $stop_insert = $conn->conn->query($stop_query);
          }

          if($stop_insert)
            {
               $msg = "<div class='alert alert-success display_msg'>Route added Successfully</div>";
               $_POST['bus_list'] = '';
               $_POST['b_source_val'] = '';
               $_POST['b_Destination_val'] = '';
               $_POST['b_fair'] = '';
               $_POST['b_seat'] = '';
               $_POST['b_desc'] = '';
               $_POST['stopname'] = '';
               //$_POST['contactno'] = '';
               $_POST['time1'] = '';
               $_POST['b_source'] = '';
               $_POST['b_Destination'] = '';
               $_POST['stopname_val'] = '';

            }else{
               $msg = "<div class='alert alert-danger display_msg'>Error occuerd</div>";
            }
        }
    }
}

?>

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>SB Admin - Bootstrap Admin Template</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/sb-admin.css" rel="stylesheet">
     <link href="css/bootstrap-datetimepicker.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" rel="Stylesheet"></link>
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>
<style>
td {
    width: 50%;
    height: 25px;
   //border: 1px solid black;
}

</style>


<body>

    <div id="wrapper">

        <!-- Navigation -->
        <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-ex1-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html">SB Admin</a>
            </div>
            <!-- Top Menu Items -->
            <ul class="nav navbar-right top-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-envelope"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu message-dropdown">
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading">
                                            <strong>John Smith</strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 4:32 PM</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur...</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading">
                                            <strong>John Smith</strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 4:32 PM</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur...</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-preview">
                            <a href="#">
                                <div class="media">
                                    <span class="pull-left">
                                        <img class="media-object" src="http://placehold.it/50x50" alt="">
                                    </span>
                                    <div class="media-body">
                                        <h5 class="media-heading">
                                            <strong>John Smith</strong>
                                        </h5>
                                        <p class="small text-muted"><i class="fa fa-clock-o"></i> Yesterday at 4:32 PM</p>
                                        <p>Lorem ipsum dolor sit amet, consectetur...</p>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <li class="message-footer">
                            <a href="#">Read All New Messages</a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-bell"></i> <b class="caret"></b></a>
                    <ul class="dropdown-menu alert-dropdown">
                        <li>
                            <a href="#">Alert Name <span class="label label-default">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-primary">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-success">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-info">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-warning">Alert Badge</span></a>
                        </li>
                        <li>
                            <a href="#">Alert Name <span class="label label-danger">Alert Badge</span></a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#">View All</a>
                        </li>
                    </ul>
                </li>
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-user"></i> John Smith <b class="caret"></b></a>
                    <ul class="dropdown-menu">
                        <li>
                            <a href="#"><i class="fa fa-fw fa-user"></i> Profile</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-envelope"></i> Inbox</a>
                        </li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-gear"></i> Settings</a>
                        </li>
                        <li class="divider"></li>
                        <li>
                            <a href="#"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- Sidebar Menu Items - These collapse to the responsive navigation menu on small screens -->
            <div class="collapse navbar-collapse navbar-ex1-collapse">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a href="index.html"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>
                    <li>
                        <a href="charts.html"><i class="fa fa-fw fa-bar-chart-o"></i> Charts</a>
                    </li>
                    <li>
                        <a href="tables.html"><i class="fa fa-fw fa-table"></i> Tables</a>
                    </li>
                    <li>
                        <a href="forms.html"><i class="fa fa-fw fa-edit"></i> Forms</a>
                    </li>
                    <li>
                        <a href="bootstrap-elements.html"><i class="fa fa-fw fa-desktop"></i> Bootstrap Elements</a>
                    </li>
                    <li>
                        <a href="bootstrap-grid.html"><i class="fa fa-fw fa-wrench"></i> Bootstrap Grid</a>
                    </li>
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#demo"><i class="fa fa-fw fa-arrows-v"></i> Dropdown <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="demo" class="collapse">
                            <li>
                                <a href="#">Dropdown Item</a>
                            </li>
                            <li>
                                <a href="#">Dropdown Item</a>
                            </li>
                        </ul>
                    </li>
                    <li class="active">
                        <a href="blank-page.html"><i class="fa fa-fw fa-file"></i> Blank Page</a>
                    </li>
                    <li>
                        <a href="index-rtl.html"><i class="fa fa-fw fa-dashboard"></i> RTL Dashboard</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </nav>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-6">
                        <h1 class="page-header">
                            Blank Page
                            <small>Subheading</small>
                        </h1>
                        <ol class="breadcrumb">
                            <li>
                                <i class="fa fa-dashboard"></i>  <a href="index.html">Dashboard</a>
                            </li>
                            <li class="active">
                                <i class="fa fa-file"></i> Blank Page
                            </li>
                        </ol>
                    </div>
                </div>

                    <div class="col-lg-12">
                        <form role="form" action="" method="post">
                            <?php if(!empty($routes_flow))
                            {   ?>
                                <div>
                            <?php 
                            if(!empty($msg))
                                {
                                    echo $msg; 
                                }
                            ?>
                            </div>
                        <div class="panel-heading" style="background: #333;color:#fff;">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" href="#collapse3">Bus Information</a>
                            </h4>
                        </div>
                        
                        <div class="col-lg-12" id="collapse3" style="border: 1px solid #333;">
                        <br />

                            <div class="form-group col-lg-4">
                                <label>Select Bus</label>
                                <!--<select  name = "bus_list" class="form-control">
                                    <?php while($buses_list = mysqli_fetch_assoc($bus_list)){?>
                                        <option value="<?php echo $buses_list['bus_id']; ?>"><?php echo $buses_list['bus_name']; ?></option>
                                    <?php } ?>
                                </select>-->
                                <input type="text" name="bus_name" id="bus_name" class="form-control" placeholder="Enter Bus Source" value="<?php echo $rout->getBusname($routes_flow['bus_id']); ?>">
                                <input type="hidden" name="bus_list" id="bus_list" class="form-control" value = "<?php echo $routes_flow['bus_id']; ?>" placeholder="Enter Bus Source" readonly>
                                <input type="hidden" name="route_id" id="route_id" class="form-control" value = "<?php echo $routes_flow['route_id']; ?>" placeholder="Enter Bus Source" readonly>
                            </div>

                            <div class="form-group col-lg-4">
                                <label>Source Name</label>
                                <input type="text" name="b_source" id="b_source" class="form-control" placeholder="Enter Bus Source" value="<?php echo $rout->getSource($routes_flow['source']); ?>" required>
                                <input type="hidden" name="b_source_val" id="b_source_val" class="form-control" value = "<?php echo $routes_flow['source']; ?>" placeholder="Enter Bus Source">
                            </div>

                            <div class="form-group col-lg-4">
                                <label>Destination Name</label>
                                <input type="text" name="b_Destination" id="b_Destination" class="form-control" placeholder="Enter Destination" value="<?php echo $rout->getdestination($routes_flow['destination']); ?>" required>
                                 <input type="hidden" name="b_Destination_val" id="b_Destination_val" class="form-control" value = "<?php echo $routes_flow['destination']; ?>" placeholder="Enter Destination" >
                            </div>

                            <div class="form-group col-lg-4">
                                <label>Bus Fair</label>
                                <input type="text" name="b_fair" class="form-control" placeholder="Enter Bus Fair" value = "<?php echo $routes_flow['bus_fair']; ?>" required>
                            </div>

                            <div class="form-group col-lg-4">
                                <label>Total Seat</label>
                                <input type="text" name="b_seat" class="form-control" placeholder="Enter total seat" value = "<?php echo $routes_flow['bus_total_seat']; ?>" required>
                            </div>
                            
                             <div class="form-group col-lg-4">
                                <label>Contact Number</label>
                                <input type="text" name="contact_no" id="contact_no" class="form-control" placeholder="Enter Contact Number" value = "<?php echo $routes_flow['contact_no']; ?>" required>
                            </div>

                            <div class="form-group col-lg-8">
                                <label>Bus Description</label>
                                <textarea name="b_desc" id="b_desc" class="form-control" placeholder="Enter Bus Description" ><?php echo $routes_flow['bus_description']; ?></textarea>
                             </div>

                             <div class="form-group col-lg-4">
                                    <label>Is Active : </label>
                                    <select class="form-control" id="status" name="status">
                                        <option value="1" <?php if($routes_flow['status'] == "1") echo 'selected="selected"'; ?>>Yes</option>
                                        <option value="0" <?php if($routes_flow['status'] == "0") echo 'selected="selected"'; ?>>No</option>
                                    </select>
                            </div> 

                            <div class="form-group col-lg-4">
                                    <label>Bus TYpe : </label>
                                    <select class="form-control" id="bus_type" name="bus_type">
                                        <option value="1" <?php if($routes_flow['bus_type'] == "1") echo 'selected="selected"'; ?>>Sitting</option>
                                        <option value="2" <?php if($routes_flow['bus_type'] == "2") echo 'selected="selected"'; ?>>Sleeper</option>
                                    </select>
                            </div> 

                        </div>
                         <p>&nbsp;</p>

                        <div class="panel-heading" style="background: #333;color:#fff;">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" href="#collapse4">Stop Information</a>
                            </h4>
                        </div>

                        <div class="col-lg-12" id="collapse4" style="border: 1px solid #333;">
                        <br />
                            <div class="form-group">
                                <table class="form-table" id="customFields">
                                    <tr valign="top">
                                        <td>
                                            
                                            <div class="form-group col-lg-3">
                                                    <label>Stop Name</label>
                                                    <input type="text" name="stopname" id="stopname" class="form-control" placeholder="Stop Name" >
                                                    <input type="hidden" name="stopname_val" id="stopname_val" class="form-control" placeholder="Enter Aarrival Date" >
                                            </div>
                                            <!--<div class="form-group">
                                                    <label>Contact Number</label>
                                                    <input type="text" name="contactno" id="contactno" class="form-control" placeholder="Contact Number" >
                                            </div>-->
                                            <div class='form-group col-lg-3'>
                                                <label>Stop Time</label>
                                                <input type='time' data-format="hh:mm:ss" class="form-control" id='datetimepicker3_' Placeholder = "Stop Time" name="time1" id="time1"/>
                                            </div>
                                            <div class='form-group col-lg-3'>
                                            <span ><label>Action</label><br /><a href="javascript:void(0);" class="addCF">Add More</a></span></div>
                                        </td>
                                    </tr>
                                </table>
                            </div>
                            <div class="form-group col-lg-12">
                                <div class="form-group col-lg-12">
                                
                                <table id="customFields1" class="table table-striped">
                                    <tbody>
                                    <tr>
                                        
                                        <th>Stop Name</th>
                                        <th>Time</th>
                                        <th>Action</th>
                                    </tr>
                                    <?php if(!empty($stop_flow)){
                                        foreach($stop_flow as $key=>$val){?>
                                    <tr valign="top">
                                   

                                        <td><img src="images/icon_arrow.png" />&nbsp;<span><?php echo $rout->getStopName($val['stop_id']); ?></span><input type="hidden" class="code" id="stopname_mul" name="stopname[]" value="<?php echo $val['stop_id']; ?>" placeholder="Stop Name" /><input type="hidden" class="code" id="stop_route_id" name="stop_route_id[]" value="<?php echo $val['stop_route_id']; ?>" placeholder=" " /> </td>

                                        <!--<td><span><?php echo $val['contact']; ?></span><input type="hidden" class="code" id="contactno_mul" name="contactno[]" value="<?php echo $val['contact']; ?>" placeholder="Contact Number" /> </td>-->

                                        <td><span><?php echo date('h:i A', strtotime($val['stop_time'])); ?></span><input type="hidden" class="code" id="time1_mul" name="time1[]" value="<?php echo $val['stop_time']; ?>" placeholder="Time" /></td>

                                        <td> <a href="javascript:void(0);" class="remCF"><span class="glyphicon glyphicon-remove"></span></a></td>
                                    </tr>
                                    <?php 
                                }}
                                else{ ?>
                                <tr></tr>
                                <?php } ?>
                                </tbody>
                                </table>
                                </div>
                            </div>
                            <?php }else {
                                ?>
                            <div>
                            <?php 
                            if(!empty($msg))
                                {
                                    echo $msg; 
                                }
                            ?>
                            </div>

                        <div class="panel-heading" style="background: #333;color:#fff;">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" href="#collapse1">Bus Information</a>
                            </h4>
                        </div>
                        
                        <div class="col-lg-12" id="collapse1" style="border: 1px solid #333;">
                        <br />
                            <div class="form-group col-lg-4">
                                <label>Select Bus</label>
                               <input type="text" name="bus_name" id="bus_name" class="form-control" placeholder="Enter Bus">
                                <input type="hidden" name="bus_list" id="bus_list" class="form-control" placeholder="Enter Bus" readonly>
                            </div>

                            <div class="form-group col-lg-4">
                                <label>Source Name</label>
                                <input type="text" name="b_source" id="b_source" class="form-control" placeholder="Enter Bus Source" required>
                                <input type="hidden" name="b_source_val" id="b_source_val" class="form-control" placeholder="Enter Bus Source">
                            </div>

                            <div class="form-group col-lg-4">
                                <label>Destination Name</label>
                                <input type="text" name="b_Destination" id="b_Destination" class="form-control" placeholder="Enter Destination" required>
                                 <input type="hidden" name="b_Destination_val" id="b_Destination_val" class="form-control" placeholder="Enter Destination" >
                            </div>

                            <div class="form-group col-lg-4">
                                <label>Bus Fair</label>
                                <input type="text" name="b_fair" class="form-control" placeholder="Enter Bus Fair" required>
                            </div>

                            <div class="form-group col-lg-4">
                                <label>Total Seat</label>
                                <input type="text" name="b_seat" class="form-control" placeholder="Enter total seat" required>
                            </div>
                            
                            <div class="form-group col-lg-4">
                                <label>Contact Number</label>
                               <input type="contact_no" name="contact_no" class="form-control" placeholder="Enter Contact Number" required>
                            </div>

                            <div class="form-group col-lg-8">
                                <label>Bus Description</label>
                                <textarea name="b_desc" id="b_desc" class="form-control" placeholder="Enter Bus Description" ></textarea>
                            </div>

                            <div class="form-group col-lg-4">
                                    <label>Is Active : </label>
                                    <select class="form-control" id="status" name="status">
                                        <option value="1">Yes</option>
                                        <option value="0">No</option>
                                    </select>
                            </div>

                            <div class="form-group col-lg-4">
                                    <label>Bus Type : </label>
                                    <select class="form-control" id="bus_type" name="bus_type">
                                        <option value="1">Yes</option>
                                        <option value="2">No</option>
                                    </select>
                            </div>

                        </div>

                        <p>&nbsp;</p>

                        <div class="panel-heading" style="background: #333;color:#fff;">
                            <h4 class="panel-title">
                                <a data-toggle="collapse" href="#collapse2">Stop Information</a>
                            </h4>
                        </div>

                        <div class="col-lg-12" id="collapse2" style="border: 1px solid #333;">
                        <br />
                            <div class="form-group">
                                <table class="form-table" id="customFields">
                                    <tr valign="top">
                                        <td>
                                            
                                            <div class="form-group col-lg-3">
                                                    <label>Stop Name</label>
                                                    <input type="text" name="stopname" id="stopname" class="form-control" placeholder="Stop Name" >
                                                    <input type="hidden" name="stopname_val" id="stopname_val" class="form-control" placeholder="Enter Aarrival Date" >
                                            </div>
                        
                                            <div class='form-group col-lg-3'>
                                                <label>Stop Time</label>
                                                <input type='time' data-format="hh:mm:ss" class="form-control" id='datetimepicker3_' Placeholder = "Stop Time" name="time1" id="time1"/>
                                            </div>
                                            <div class='form-group col-lg-3'>
                                            <span ><label>Action</label><br /><a href="javascript:void(0);" class="addCF">Add More</a></span>
                                            </div>
                                        </td>
                                    </tr>
                                </table>
                             </div>

                            <div class="col-lg-12">
                            <div class="form-group col-lg-12">
                                <table id="customFields1" class="table table-striped">
                                    <tbody>
                                        <tr>
                                            
                                            <th>Stop Name</th>
                                            <th>Time</th>
                                            <th>Action</th>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <?php } ?>
                            <button type="submit" name="submit" value="submit" class="btn btn-blue">Submit</button>
                            <p>&nbsp;</p>
                        </div>
                        
                        </div>
                        
                            
                        </form>
                    </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/bootstrap-datetimepicker.min.js"></script>



    <script>
    $(document).ready(function(){

        function tConvert (time) {
   // Check correct time format and split into components
   time = time.toString ().match (/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) { // If time format correct
      time = time.slice (1);  // Remove full string match value
      time[5] = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    return time.join (''); // return adjusted time or original string
  }

        $(function() {
            $( "tbody" ).sortable();
            $( "tbody" ).disableSelection();
          });

        $('.display_msg').fadeOut(6000);
        $(".addCF").click(function(){

        var stop_name = $("input[name=stopname").val();
        var stop_name_val = $("input[name=stopname_val").val();
        var time1 = $("input[name=time1]").val();

        if(stop_name != '' && time1 != '')
        {
             $("#customFields1").append('<tr valign="top"><td><span><img src="images/icon_arrow.png" />&nbsp;'+ stop_name +'</span><input type="hidden" class="code" id="stopname_mul" name="stopname[]" value='+stop_name_val+' placeholder="Stop Name" /> </td><td><span>'+ tConvert(time1) +'</span><input type="hidden" class="code" id="time1_mul" name="time1[]" value="'+ time1 +'" placeholder="Time" /></td><td> <a href="javascript:void(0);" class="remCF"><span class="glyphicon glyphicon-remove"></span></a></td></tr>');

        }else
        {
            alert('Please Enter Stop Name and Time');
            return false;
        }
            $("input[name=stopname").val('');
            $("input[name=time1").val('');
        });
        $("#customFields1").on('click','.remCF',function(){
        $(this).parent().parent().remove();
        });
        
    });

$(function() {
    
    var stop_data = <?php echo $stop_result_data; ?>;
    var bus_data = <?php echo $result_data_bus; ?>;
    var city_data = <?php echo $city_result_data ; ?>;
   // previousValue = '';
    $("#bus_name").autocomplete({        
        source: bus_data,
        select: function( event, ui ) {
            $( "#bus_name" ).val( ui.item.label);
            $( "#bus_list" ).val( ui.item.value); //ui.item is your object from the array
            return false;
        }
    });

    $("#stopname").autocomplete({        
        source: stop_data,
        select: function( event, ui ) {
            $( "#stopname" ).val( ui.item.label);
            $( "#stopname_val" ).val( ui.item.value); //ui.item is your object from the array
            return false;
        }
    });

    $("#b_Destination").autocomplete({        
        source: city_data,
        select: function( event, ui ) {
            $( "#b_Destination" ).val( ui.item.label);
            $( "#b_Destination_val" ).val( ui.item.value); //ui.item is your object from the array
            return false;
        }
    });

     $("#b_source").autocomplete({        
        source: city_data,
        select: function( event, ui ) {
            $( "#b_source" ).val( ui.item.label);
            $( "#b_source_val" ).val( ui.item.value);
            return false; //ui.item is your object from the array
        }
    });
});
// $(function() {
//     $('#datetimepicker3').datetimepicker({
//       pickDate: false
//     });
//   });

 function check_validation()
 {
    var stop_name = $('#stopname').val();
    //var contatc_number = $('#contactno').val();
    var date = $('#datetimepicker3').val();

    if(stop_name == '')
    {
        alert('Please Enter Stop Name');
        $('#stopname').focus();
        return false;
    }else if(date == '')
    {
        alert('Please Enter Stop Time');
        $('#datetimepicker3').focus();
        return false;
    }
 }

    </script>


</body>

</html>
