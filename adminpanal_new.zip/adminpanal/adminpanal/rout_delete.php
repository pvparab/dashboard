<?php
include('data_config.php');
$conn = new connection;

    $query_del = "update bus_route_master set is_delete = 1 where route_id = ".$_GET['rout_id'];
    $result = $conn->conn->query($query_del);
    if($result)
    {
    	header('Location:routes.php');
    }
?>