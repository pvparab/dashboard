<?php
include('data_config.php');
$conn = new connection;

    $query_del = "update master_stop set is_delete = 1 where stop_id = ".$_GET['stop_delete_id'];
    $result = $conn->conn->query($query_del);
    if($result)
    {
    	header('Location:Buses.php');
    }
?>