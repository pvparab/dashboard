<?php
// var_dump($conn);die;
class Route extends connection {

	public function __construct()
	{
		parent::__construct();
	}

    Public function getSource($source_id) { 
    	$source_name = '';

        $qry = "select city_name from masters_city where is_delete = 0 and city_id = ".$source_id;
    	
        $result = $this->conn->query($qry);

        while($row = mysqli_fetch_assoc($result))
        {
        	$source_name = $row['city_name'];
        }
        return $source_name;
    } 

    Public function getdestination($destination) { 
    	$destination_name = '';

        $qry = "select city_name from masters_city where is_delete = 0 and city_id = ".$destination;
    	
        $result = $this->conn->query($qry);

        while($row = mysqli_fetch_assoc($result))
        {
        	$destination_name = $row['city_name'];
        }
        return $destination_name;
    } 

     Public function getStopName($stop) { 
    	$stop_name = '';

        $qry = "select stop_name from master_stop where is_delete = 0 and stop_id = ".$stop;
    	
        $result = $this->conn->query($qry);

        while($row = mysqli_fetch_assoc($result))
        {
        	$stop_name = $row['stop_name'];
        }
        return $stop_name;
    } 

     Public function getBusname($bus) { 
    	$bus_name = '';

        $qry = "select bus_name from master_bus where is_delete = 0 and bus_id = ".$bus;
    	
        $result = $this->conn->query($qry);

        while($row = mysqli_fetch_assoc($result))
        {
        	$bus_name = $row['bus_name'];
        }
        return $bus_name;
    } 
}

?>