<?php
$conn = new mysqli('localhost','root','','bus_online_reservation');

class connection{

	public $conn;

	function __construct()
	{
		$this->conn = new mysqli('localhost','root','','bus_online_reservation');
	}

}


?>