-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2016 at 04:27 AM
-- Server version: 5.6.17-log
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bus_online_reservation`
--

-- --------------------------------------------------------

--
-- Table structure for table `bus_route_master`
--

CREATE TABLE IF NOT EXISTS `bus_route_master` (
  `route_id` int(11) NOT NULL AUTO_INCREMENT,
  `source` varchar(50) NOT NULL,
  `destination` varchar(50) NOT NULL,
  `bus_id` int(11) NOT NULL,
  `bus_fair` int(20) NOT NULL,
  `bus_total_seat` int(20) NOT NULL,
  `sold_seat_no` varchar(50) NOT NULL,
  `aval_seat_no` varchar(50) NOT NULL,
  `bus_description` longtext NOT NULL,
  `status` int(11) NOT NULL,
  `contact_no` varchar(50) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  `is_delete` int(11) NOT NULL,
  PRIMARY KEY (`route_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `bus_route_master`
--

INSERT INTO `bus_route_master` (`route_id`, `source`, `destination`, `bus_id`, `bus_fair`, `bus_total_seat`, `sold_seat_no`, `aval_seat_no`, `bus_description`, `status`, `contact_no`, `created_date`, `updated_date`, `is_delete`) VALUES
(3, '1', '2', 14, 780, 70, '', '', 'Full Ac Bus All rights Reserved', 0, '9987454602', '2016-06-05 08:10:53', '2016-06-06 06:31:39', 0),
(4, '4', '3', 14, 470, 70, '', '', 'bbc', 0, '', '2016-06-05 08:19:51', '0000-00-00 00:00:00', 0),
(5, '4', '3', 14, 470, 70, '', '', 'ccd', 0, '', '2016-06-05 08:22:30', '0000-00-00 00:00:00', 0),
(6, '3', '4', 14, 700, 60, '', '', 'xyz', 0, '', '2016-06-05 08:30:29', '0000-00-00 00:00:00', 0),
(8, '1', '4', 15, 780, 70, '', '', 'Full Air condition, DVD Coach', 1, '7718071091', '2016-06-06 06:44:14', '2016-06-06 08:16:10', 0);

-- --------------------------------------------------------

--
-- Table structure for table `masters_city`
--

CREATE TABLE IF NOT EXISTS `masters_city` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `is_delete` int(11) NOT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `masters_city`
--

INSERT INTO `masters_city` (`city_id`, `city_name`, `status`, `created_date`, `is_delete`) VALUES
(1, 'Mumbai', 0, '2016-06-04 00:00:00', 0),
(2, 'Goa', 0, '2016-06-04 00:00:00', 0),
(3, 'Kolhapur', 1, '2016-06-04 00:00:00', 0),
(4, 'Satara', 0, '2016-06-04 00:00:00', 0),
(5, 'wai vasai', 1, '2016-06-05 04:37:00', 1);

-- --------------------------------------------------------

--
-- Table structure for table `master_bus`
--

CREATE TABLE IF NOT EXISTS `master_bus` (
  `bus_id` int(11) NOT NULL AUTO_INCREMENT,
  `bus_name` varchar(200) NOT NULL,
  `bus_Number` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `bus_registered_date` datetime NOT NULL,
  `is_delete` int(11) NOT NULL,
  PRIMARY KEY (`bus_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `master_bus`
--

INSERT INTO `master_bus` (`bus_id`, `bus_name`, `bus_Number`, `status`, `bus_registered_date`, `is_delete`) VALUES
(14, 'neeta travel', 'n-1233', 0, '2016-06-03 00:00:00', 0),
(15, 'giroba', 'g-1231', 1, '2016-06-03 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `master_bus_route`
--

CREATE TABLE IF NOT EXISTS `master_bus_route` (
  `bus_route_id` int(11) NOT NULL AUTO_INCREMENT,
  `bus_id` int(11) NOT NULL,
  `bus_src` varchar(200) NOT NULL,
  `bus_desti` varchar(200) NOT NULL,
  `bus_fair` int(200) NOT NULL,
  `is_delete` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  PRIMARY KEY (`bus_route_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `master_city`
--

CREATE TABLE IF NOT EXISTS `master_city` (
  `city_id` int(11) NOT NULL,
  `city_name` varchar(200) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `is_delete` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master_city`
--

INSERT INTO `master_city` (`city_id`, `city_name`, `status`, `created_date`, `is_delete`) VALUES
(0, 'Mumbai', 0, '2016-06-04 00:00:00', 0),
(0, 'Goa', 0, '2016-06-04 00:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `master_stop`
--

CREATE TABLE IF NOT EXISTS `master_stop` (
  `stop_id` int(11) NOT NULL AUTO_INCREMENT,
  `stop_name` varchar(50) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `is_delete` int(11) NOT NULL,
  PRIMARY KEY (`stop_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `master_stop`
--

INSERT INTO `master_stop` (`stop_id`, `stop_name`, `status`, `created_date`, `is_delete`) VALUES
(1, 'stop121', 1, '2016-06-04 00:00:00', 0),
(2, 'stop221', 1, '2016-06-04 00:00:00', 0),
(3, 'kalva', 1, '2016-06-04 00:00:00', 0),
(4, 'thane', 1, '2016-06-04 00:00:00', 0),
(5, 'airoli', 1, '2016-06-04 00:00:00', 0),
(6, 'Panve;', 1, '2016-06-11 00:00:00', 0),
(7, 'stop12', 1, '2016-06-05 04:28:40', 0),
(8, 'stop12', 1, '2016-06-05 04:29:08', 0),
(9, 'stop112', 1, '2016-06-05 04:30:38', 0),
(10, 'vidyavihar', 1, '2016-06-05 04:36:38', 0);

-- --------------------------------------------------------

--
-- Table structure for table `route_bus_stop_master`
--

CREATE TABLE IF NOT EXISTS `route_bus_stop_master` (
  `stop_route_id` int(11) NOT NULL AUTO_INCREMENT,
  `route_id` int(11) NOT NULL,
  `stop_id` int(11) NOT NULL,
  `stop_time` time NOT NULL,
  `stop_order` int(11) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  `is_delete` int(11) NOT NULL,
  PRIMARY KEY (`stop_route_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=39 ;

--
-- Dumping data for table `route_bus_stop_master`
--

INSERT INTO `route_bus_stop_master` (`stop_route_id`, `route_id`, `stop_id`, `stop_time`, `stop_order`, `created_date`, `updated_date`, `is_delete`) VALUES
(5, 4, 3, '11:55:00', 0, '2016-06-05 08:19:51', '0000-00-00 00:00:00', 0),
(6, 5, 3, '11:55:00', 0, '2016-06-05 08:22:30', '0000-00-00 00:00:00', 0),
(7, 6, 3, '11:54:00', 0, '2016-06-05 08:30:29', '0000-00-00 00:00:00', 0),
(8, 0, 3, '11:54:00', 0, '2016-06-05 08:32:10', '0000-00-00 00:00:00', 0),
(9, 0, 3, '00:00:00', 0, '2016-06-05 08:32:10', '0000-00-00 00:00:00', 0),
(10, 0, 9, '11:50:00', 0, '2016-06-05 07:35:37', '0000-00-00 00:00:00', 0),
(21, 3, 3, '00:00:00', 0, '2016-06-06 06:31:39', '0000-00-00 00:00:00', 0),
(22, 3, 10, '00:00:00', 1, '2016-06-06 06:31:39', '0000-00-00 00:00:00', 0),
(23, 3, 4, '00:00:00', 2, '2016-06-06 06:31:39', '0000-00-00 00:00:00', 0),
(24, 3, 8, '00:00:00', 3, '2016-06-06 06:31:39', '0000-00-00 00:00:00', 0),
(25, 7, 3, '00:00:00', 0, '2016-06-06 06:36:22', '0000-00-00 00:00:00', 0),
(26, 7, 4, '00:00:00', 1, '2016-06-06 06:36:22', '0000-00-00 00:00:00', 0),
(27, 7, 10, '00:00:00', 2, '2016-06-06 06:36:22', '0000-00-00 00:00:00', 0),
(28, 8, 4, '00:00:00', 1, '2016-06-06 06:44:14', '2016-06-06 08:16:10', 0),
(29, 8, 10, '00:00:00', 4, '2016-06-06 06:44:14', '2016-06-06 08:16:10', 0),
(30, 8, 4, '00:00:00', 2, '2016-06-06 06:44:14', '0000-00-00 00:00:00', 1),
(31, 8, 1, '00:00:00', 2, '2016-06-06 06:44:56', '2016-06-06 06:52:49', 1),
(32, 8, 3, '00:00:00', 2, '2016-06-06 06:53:34', '2016-06-06 08:16:10', 0),
(33, 8, 1, '00:00:00', 3, '2016-06-06 07:15:29', '0000-00-00 00:00:00', 1),
(34, 8, 2, '00:00:00', 4, '2016-06-06 07:15:29', '0000-00-00 00:00:00', 1),
(35, 8, 2, '14:10:00', 3, '2016-06-06 07:16:52', '2016-06-06 07:17:28', 1),
(36, 8, 1, '06:02:00', 4, '2016-06-06 07:17:28', '0000-00-00 00:00:00', 1),
(37, 8, 1, '14:01:00', 3, '2016-06-06 07:41:50', '2016-06-06 08:16:10', 0),
(38, 8, 2, '03:02:00', 0, '2016-06-06 07:41:50', '2016-06-06 08:16:10', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
